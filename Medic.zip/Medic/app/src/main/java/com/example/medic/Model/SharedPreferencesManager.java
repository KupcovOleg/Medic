package com.example.medic.Model;

import android.content.Context;
import android.content.SharedPreferences;

//    Класс для работы с SharedPreferences, не использован
//    12.04.23
//    Баюков Даниил

public class SharedPreferencesManager {

    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    public SharedPreferencesManager(Context context) {
        this.sharedPreferences = context.getSharedPreferences("sharedPrefs", Context.MODE_PRIVATE);
        this.editor = sharedPreferences.edit();
    }

    public boolean getOnboardState() {
        return sharedPreferences.getBoolean("onboardState", false);
    }

    public void setOnboardState(boolean b) {
        editor.putBoolean("onboardState", b);
        editor.apply();
    }

    public void saveToken(String token) {
        editor.putString("token", token);
        editor.apply();
    }

    public void saveAddress(String address, int l, int w, int h, int appartment, int entrance, int floor) {
        editor.putString("address", address);
        editor.putInt("l", l);
        editor.putInt("w", w);
        editor.putInt("h", h);
        editor.putInt("apartment", appartment);
        editor.putInt("entrance", entrance);
        editor.putInt("floor", floor);
        editor.apply();
    }

    public Address getAddress() {
        return new Address(sharedPreferences.getString("address", ""),
                sharedPreferences.getInt("l", 0),
                sharedPreferences.getInt("w", 0),
                sharedPreferences.getInt("h", 0),
                sharedPreferences.getInt("apartment", 0),
                sharedPreferences.getInt("entrance", 0),
                sharedPreferences.getInt("floor", 0));
    }

    public String getToken() {
        return sharedPreferences.getString("token", "");
    }
}
