package com.example.medic.Controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.medic.Model.App;
import com.example.medic.Model.MedicApiAdapter;
import com.example.medic.Model.EmailResponse;
import com.example.medic.Model.SharedPreferencesManager;
import com.example.medic.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//    Класс регистрации для следующей сессии
//    12.04.23
//    Баюков Даниил
public class RegisterActivity extends AppCompatActivity {

    private AppCompatButton nextButton;
    private EditText emailEdit;

    private App app;
    private MedicApiAdapter medicApiAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        app = (App) getApplication();
        medicApiAdapter = app.getMedicApiAdapter();
        SharedPreferencesManager sharedPreferencesManager = app.getSharedPreferencesManager();
        if (sharedPreferencesManager.getToken().length() != 0) {
            toPinCreation();
        }
        setContentView(R.layout.activity_register);

        nextButton = findViewById(R.id.next_button);
        emailEdit = findViewById(R.id.email_edit_text);

        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCode();
            }
        });

        emailEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                validateMail(emailEdit.getText().toString());
            }

            @Override
            public void afterTextChanged(Editable s) {


            }
        });

    }

    private void sendCode() {
        nextButton.setEnabled(false);
        nextButton.setBackgroundDrawable(getDrawable(R.drawable.button_inactive_blue));

        Call<EmailResponse> call = medicApiAdapter.getApi().requestCode(emailEdit.getText().toString());
        call.enqueue(new Callback<EmailResponse>() {
            @Override
            public void onResponse(Call<EmailResponse> call, Response<EmailResponse> response) {
                System.out.println(response.code());
                if (response.code() == 200) {
                    toCodeEntering(emailEdit.getText().toString());
                } else {
                    Toast.makeText(getApplicationContext(), "Произошла ошибка", Toast.LENGTH_SHORT);
                }
            }

            @Override
            public void onFailure(Call<EmailResponse> call, Throwable t) {

            }
        });

        nextButton.setEnabled(true);
        nextButton.setBackgroundDrawable(getDrawable(R.drawable.button_active_blue));
    }

    private void toCodeEntering(String email) {
        Intent intent = new Intent(this, CodeEnteringActivity.class);
        intent.putExtra("email", email);
        startActivity(intent);
    }

    private void toPinCreation() {
        Intent intent = new Intent(this, PinCreationActivity.class);
        startActivity(intent);
        this.finish();
    }

    private void validateMail(String email) {
        if (Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            nextButton.setEnabled(true);
            nextButton.setBackgroundDrawable(getDrawable(R.drawable.button_active_blue));
        } else {
            nextButton.setEnabled(false);
            nextButton.setBackgroundDrawable(getDrawable(R.drawable.button_inactive_blue));
    }}
}