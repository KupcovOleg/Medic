package com.example.medic.Model;

public class EmailResponse {

    private String message;

    public EmailResponse(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
