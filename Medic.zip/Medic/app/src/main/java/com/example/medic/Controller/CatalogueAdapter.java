package com.example.medic.Controller;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medic.Model.CartManager;
import com.example.medic.Model.CatalogueResponse;
import com.example.medic.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.List;

public class CatalogueAdapter extends RecyclerView.Adapter<CatalogueAdapter.CatalogueResponseView> {

    private List<CatalogueResponse> catalogueResponseList;
    private Context context;
    private BottomSheetDialog bottomSheetDialog;

    private TextView bottomSheetTitle;
    private TextView bottomSheetDescription;
    private TextView bottomSheetPreparation;
    private TextView bottomSheetResultTime;
    private TextView bottomSheetBiomaterial;
    private AppCompatButton bottomSheedAdd;
    private AppCompatButton bottomSheetClose;

    private CartManager cartManager;
    public CatalogueAdapter(List<CatalogueResponse> catalogueResponseList, Context context, BottomSheetDialog bottomSheetDialog, CartManager cartManager) {
        this.catalogueResponseList = catalogueResponseList;
        this.context = context;
        this.bottomSheetDialog = bottomSheetDialog;

        bottomSheetTitle = bottomSheetDialog.findViewById(R.id.title);
        bottomSheetDescription = bottomSheetDialog.findViewById(R.id.description);
        bottomSheetPreparation = bottomSheetDialog.findViewById(R.id.preparation);
        bottomSheetResultTime = bottomSheetDialog.findViewById(R.id.result_time);
        bottomSheetBiomaterial = bottomSheetDialog.findViewById(R.id.biomaterial);
        bottomSheetClose = bottomSheetDialog.findViewById(R.id.close);
        bottomSheedAdd = bottomSheetDialog.findViewById(R.id.add);

        this.cartManager = cartManager;
    }

    @NonNull
    @Override
    public CatalogueResponseView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.catalogue_element_view, parent, false);
        return new CatalogueResponseView(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CatalogueResponseView holder, int position) {

        holder.title.setText(catalogueResponseList.get(position).getName());
        holder.description.setText(catalogueResponseList.get(position).getTime_result());
        holder.price.setText(catalogueResponseList.get(position).getPrice() + " P");

        if (cartManager.getCartList().contains(catalogueResponseList.get(position))) {
            holder.addButton.setBackgroundResource(R.drawable.button_incative_white);
            holder.addButton.setText("Убрать");
            holder.addButton.setTextColor(Color.parseColor("#1A6FEE"));
        } else {
            holder.addButton.setBackgroundResource(R.drawable.button_active_blue);
            holder.addButton.setText("Добавить");
            holder.addButton.setTextColor(Color.parseColor("#FFFFFF"));
        }

        if (catalogueResponseList.get(holder.getAdapterPosition()).getAmount() > 0) {
            holder.addButton.setBackgroundResource(R.drawable.button_incative_white);
            holder.addButton.setText("Убрать");
            holder.addButton.setTextColor(Color.parseColor("#1A6FEE"));
        }
        holder.card.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bottomSheetTitle.setText(catalogueResponseList.get(holder.getAdapterPosition()).getName());
                bottomSheetDescription.setText(catalogueResponseList.get(holder.getAdapterPosition()).getDescription());
                bottomSheetPreparation.setText(catalogueResponseList.get(holder.getAdapterPosition()).getPreparation());
                bottomSheetResultTime.setText(catalogueResponseList.get(holder.getAdapterPosition()).getTime_result());
                bottomSheetBiomaterial.setText(catalogueResponseList.get(holder.getAdapterPosition()).getBio());
                bottomSheedAdd.setText("Добавить за " + catalogueResponseList.get(holder.getAdapterPosition()).getPrice() + " Р");
                bottomSheetDialog.show();
                bottomSheetClose.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        bottomSheetDialog.cancel();
                    }
                });
            }
        });

        holder.addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (catalogueResponseList.get(holder.getAdapterPosition()).getAmount() == 0) {
                    cartManager.addElement(catalogueResponseList.get(holder.getAdapterPosition()));
                    notifyDataSetChanged();
                } else {
                    cartManager.clearElement(catalogueResponseList.get(holder.getAdapterPosition()));
                    notifyDataSetChanged();
                }

            }
        });

    }

    @Override
    public int getItemCount() {
        return catalogueResponseList.size();
    }

    public class CatalogueResponseView extends RecyclerView.ViewHolder {

        private TextView title;
        private TextView description;
        private TextView price;
        private AppCompatButton addButton;
        private CardView card;


        public CatalogueResponseView(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.title);
            description = itemView.findViewById(R.id.description);
            price = itemView.findViewById(R.id.price);
            addButton = itemView.findViewById(R.id.add_button);
            card = itemView.findViewById(R.id.card);

        }
    }
}
