package com.example.medic.Model;

public class Address {

    private String address;
    private int l;
    private int w;
    private int h;
    private int apartment;
    private int entrance;
    private int floor;

    public Address(String address, int l, int w, int h, int apartment, int entrance, int floor) {
        this.address = address;
        this.l = l;
        this.w = w;
        this.h = h;
        this.apartment = apartment;
        this.entrance = entrance;
        this.floor = floor;
    }

    public String getAddress() {
        return address;
    }

    public int getL() {
        return l;
    }

    public int getW() {
        return w;
    }

    public int getH() {
        return h;
    }

    public int getApartment() {
        return apartment;
    }

    public int getEntrance() {
        return entrance;
    }

    public int getFloor() {
        return floor;
    }
}
