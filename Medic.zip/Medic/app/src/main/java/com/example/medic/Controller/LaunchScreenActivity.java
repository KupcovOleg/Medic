package com.example.medic.Controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.example.medic.R;

//    Класс активити экрана запуска
//    12.04.23
//    Баюков Даниил
public class LaunchScreenActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launch_screen);

        WindowCompat.setDecorFitsSystemWindows(this.getWindow(), false);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(LaunchScreenActivity.this, OnboardActivity.class));
            }
        }, 2000);
    }
}