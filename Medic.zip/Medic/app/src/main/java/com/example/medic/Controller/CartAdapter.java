package com.example.medic.Controller;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medic.Model.CartManager;
import com.example.medic.Model.CatalogueResponse;
import com.example.medic.R;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartElementView> {

    private CartManager cartManager;
    private List<CatalogueResponse> cartList;

    public CartAdapter(CartManager cartManager) {
        this.cartManager = cartManager;
        this.cartList = cartManager.getCartList();
    }

    @NonNull
    @Override
    public CartElementView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_element_view, parent, false);
        return new CartElementView(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartElementView holder, int position) {
        holder.title.setText(cartList.get(position).getName());
        holder.price.setText(cartList.get(position).getPrice() + " Р");
        holder.amount.setText("Пациенты: " + cartList.get(position).getAmount());

        holder.plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cartManager.addElement(cartManager.getCartList().get(holder.getAdapterPosition()));
                notifyDataSetChanged();
            }
        });

        holder.minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cartManager.removeElement(cartManager.getCartList().get(holder.getAdapterPosition()));
                notifyDataSetChanged();
            }
        });

        holder.delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cartManager.clearElement(cartManager.getCartList().get(holder.getAdapterPosition()));
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return cartList.size();
    }

    public class CartElementView extends RecyclerView.ViewHolder {

        private TextView title;
        private TextView price;
        private TextView amount;
        private ImageView delete;
        private ImageView minus;
        private ImageView plus;

        public CartElementView(@NonNull View itemView) {
            super(itemView);

            this.title = itemView.findViewById(R.id.title);
            this.price = itemView.findViewById(R.id.price);
            this.amount = itemView.findViewById(R.id.patient);
            this.delete = itemView.findViewById(R.id.delete);
            this.minus = itemView.findViewById(R.id.minus);
            this.plus = itemView.findViewById(R.id.plus);
        }
    }
}
