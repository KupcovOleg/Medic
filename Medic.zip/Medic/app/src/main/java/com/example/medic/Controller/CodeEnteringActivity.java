package com.example.medic.Controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.medic.Model.App;
import com.example.medic.Model.MedicApiAdapter;
import com.example.medic.Model.EmailResponse;
import com.example.medic.Model.TokenResponse;
import com.example.medic.Model.SharedPreferencesManager;
import com.example.medic.R;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CodeEnteringActivity extends AppCompatActivity {

    private String email;

    private TextView textTimer;
    private EditText codeEdit;
    private AppCompatButton back;
    private TextView resend;

    private App app;
    private MedicApiAdapter medicApiAdapter;
    private SharedPreferencesManager sharedPreferencesManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        app = (App) getApplication();
        medicApiAdapter = app.getMedicApiAdapter();
        sharedPreferencesManager = app.getSharedPreferencesManager();

        setContentView(R.layout.activity_code_entering);

        Intent intent = getIntent();
        email = intent.getStringExtra("email");

        textTimer = findViewById(R.id.timer);
        codeEdit = findViewById(R.id.code_edit);
        back = findViewById(R.id.back);
        resend = findViewById(R.id.resend_code);

        resend.setEnabled(false);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finishAct();
            }
        });

        setTimer();

        resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendCode();
                setTimer();
            }
        });

        codeEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (codeEdit.getText().toString().length() == 4) {
                    requestToken(codeEdit.getText().toString());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    private void setTimer() {
        resend.setTextColor(Color.parseColor("#939396"));
        CountDownTimer count = new CountDownTimer(60000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                textTimer.setText(
                        "Отправить код повторно можно будет через " + millisUntilFinished / 1000 + " секунд"
                );
            }

            @Override
            public void onFinish() {
                resend.setEnabled(true);
                resend.setTextColor(Resources.getSystem().getColor(R.color.text_dark_blue));
            }
        };
        count.start();
    }

    private void finishAct() {
        this.finish();
    }

    private void sendCode() {
        Call<EmailResponse> call = medicApiAdapter.getApi().requestCode(email);
        call.enqueue(new Callback<EmailResponse>() {
            @Override
            public void onResponse(Call<EmailResponse> call, Response<EmailResponse> response) {
                if (response.code() == 200) {
                    setTimer();
                } else {
                    Toast.makeText(getApplicationContext(), "Произошла ошибка", Toast.LENGTH_SHORT);
                }
            }

            @Override
            public void onFailure(Call<EmailResponse> call, Throwable t) {

            }
        });
    }

    private void requestToken(String code) {
        Call<TokenResponse> call = medicApiAdapter.getApi().requestToken(email, code);
        call.enqueue(new Callback<TokenResponse>() {
            @Override
            public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {
                if (response.code() == 200) {
                    String token = response.body().getToken();
                    saveToken(token);
                }
            }

            @Override
            public void onFailure(Call<TokenResponse> call, Throwable t) {

            }
        });
    }

    private void saveToken(String token) {
        sharedPreferencesManager.saveToken(token);
    }

    private void toNextActivity() {
        Intent intent = new Intent(this, PinCreationActivity.class);
        startActivity(intent);
        finishAct();
    }
}