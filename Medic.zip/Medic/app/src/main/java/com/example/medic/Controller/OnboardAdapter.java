package com.example.medic.Controller;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.medic.Model.OnboardElement;
import com.example.medic.R;

import java.util.List;

//    Класс адаптера для активити экрана приветствия
//    12.04.23
//    Баюков Даниил

public class OnboardAdapter extends RecyclerView.Adapter<OnboardAdapter.OnboardElementView> {

    public OnboardAdapter(List<OnboardElement> onboardElementList) {
        this.onboardElementList = onboardElementList;
    }

    private List<OnboardElement> onboardElementList;

    @NonNull
    @Override
    public OnboardElementView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new OnboardElementView(LayoutInflater.from(parent.getContext()).inflate(R.layout.onboard_element_view, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull OnboardElementView holder, int position) {
        holder.title.setText(onboardElementList.get(position).getTitle());
        holder.description.setText(onboardElementList.get(position).getDescription());
        holder.image.setImageDrawable(onboardElementList.get(position).getImage());
    }

    @Override
    public int getItemCount() {
        return onboardElementList.size();
    }

    public class OnboardElementView extends RecyclerView.ViewHolder {

        private TextView title;
        private TextView description;
        private ImageView image;

        public OnboardElementView(@NonNull View itemView) {
            super(itemView);

            this.title = itemView.findViewById(R.id.onboard_element_title);
            this.description = itemView.findViewById(R.id.onboard_element_description);
            this.image = itemView.findViewById(R.id.onboard_element_image);
        }
    }
}
