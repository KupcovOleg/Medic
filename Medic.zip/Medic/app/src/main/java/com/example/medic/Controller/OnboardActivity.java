package com.example.medic.Controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.medic.Model.App;
import com.example.medic.Model.OnboardElement;
import com.example.medic.R;

import java.util.ArrayList;
import java.util.List;


//    Класс активити экрана приветствия
//    12.04.23
//    Баюков Даниил
public class OnboardActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private OnboardAdapter adapter;

    private TextView skipButton;
    private LinearLayout dotsIndicator;
    private ImageView[] dots;

    private List<OnboardElement> onboardElementList;

    private App app;
//    private SharedPreferencesManager sharedPreferencesManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        app = (App) getApplication();
//        sharedPreferencesManager = app.getSharedPreferencesManager();

        if (getViewedState()) {
            toNextActivity();
        }
        setContentView(R.layout.activity_onboard);

        viewPager = findViewById(R.id.onboard_adapter_view);
        skipButton = findViewById(R.id.skip);
        dotsIndicator = findViewById(R.id.dots_indicator);
        dots = new ImageView[3];
        onboardElementList = new ArrayList<>();
        setupOnboardAdapter();

        skipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toNextActivity();
            }
        });
    }

    //Метод в котором создается и инициализируется объект класса ViewPagerAdapter

    private void setViewPager() {
        adapter = new OnboardAdapter(onboardElementList);
        viewPager.setAdapter(adapter);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);

                setOnboardIndicator(position);
                setCurrentSkipButtonTitle(position);
            }
        });
    }

    //Метод для наполнения списка элементов экрана приветствия

    private void setupOnboardAdapter() {
        System.out.println("onboard_title_" + 0);

        OnboardElement element1 = new OnboardElement(
                getString(R.string.onboard_title_0),
                getString(R.string.onboard_description_0),
                getDrawable(R.drawable.onboard_image_0)
        );

        onboardElementList.add(element1);

        OnboardElement element2 = new OnboardElement(
                getString(R.string.onboard_title_1),
                getString(R.string.onboard_description_1),
                getDrawable(R.drawable.onboard_image_1)
        );

        onboardElementList.add(element2);

        OnboardElement element3 = new OnboardElement(
                getString(R.string.onboard_title_2),
                getString(R.string.onboard_description_2),
                getDrawable(R.drawable.onboard_image_2)
        );

        onboardElementList.add(element3);

        setupOnboardIndicator();
        setViewPager();
    }

    //Метод в котором создаются индикаторы экрана приветствия внутри LinearLayout

    private void setupOnboardIndicator() {

        for (int i = 0; i < dots.length; i++) {
            dots[i] = new ImageView(this);
            dots[i].setImageResource(R.drawable.onboard_dot_inactive);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            layoutParams.setMargins(8, 0, 8, 0);
            dots[i].setLayoutParams(layoutParams);
            dotsIndicator.addView(dots[i]);
        }
    }

    //Метод в котором устанавливается активный индикатор

    private void setOnboardIndicator(int position) {
        for (int i = 0; i < dotsIndicator.getChildCount(); i++) {
            ImageView dot = (ImageView) dotsIndicator.getChildAt(i);
            dot.setImageResource(R.drawable.onboard_dot_inactive);
        }
        ImageView dot = (ImageView) dotsIndicator.getChildAt(position);
        dot.setImageResource(R.drawable.onboard_dot_active);
    }

    //Метод который устанавливает соответствующий текст на кнопку "пропустить"

    private void setCurrentSkipButtonTitle(int position) {
        switch (position) {
            case 2:
                skipButton.setText("Завершить");
                break;
            default:
                skipButton.setText("Пропустить");
                break;
        }
    }

    //Метод перехода на следующее активити

    private void toNextActivity() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
        if (!getViewedState()) {
            saveViewedState();
        }
        this.finish();
    }

    //Метод для сохранения состояния просмотренного экрана приветствия

    private void saveViewedState() {
        SharedPreferences sharedPreferences = this.getSharedPreferences("sharedPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("onboardState", true);
        editor.apply();
    }

    //Метод для проверки состояния просмотренного экрана приветствия
    private boolean getViewedState() {
        SharedPreferences sharedPreferences = this.getSharedPreferences("sharedPrefs", Context.MODE_PRIVATE);
        return sharedPreferences.getBoolean("onboardState", false);
    }

}