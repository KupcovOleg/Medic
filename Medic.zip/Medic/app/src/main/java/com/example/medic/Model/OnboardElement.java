package com.example.medic.Model;

import android.graphics.drawable.Drawable;

//    Класс элемента экрана приветствия
//    12.04.23
//    Баюков Даниил
public class OnboardElement {

    private String title;
    private String description;
    private Drawable image;

    public OnboardElement(String title, String description, Drawable image) {
        this.title = title;
        this.description = description;
        this.image = image;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public Drawable getImage() {
        return image;
    }
}
