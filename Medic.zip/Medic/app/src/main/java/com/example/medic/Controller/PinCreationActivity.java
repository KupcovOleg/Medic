package com.example.medic.Controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.medic.R;

public class PinCreationActivity extends AppCompatActivity {

    private TextView skip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pin_creation);

        skip = findViewById(R.id.skip);

        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toCardCreation();
            }
        });
    }

    private void toCardCreation() {
        Intent intent = new Intent(this, CardCreationActivity.class);
        startActivity(intent);
    }
}