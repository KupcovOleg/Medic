package com.example.medic.Controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.example.medic.Model.App;
import com.example.medic.Model.CartManager;
import com.example.medic.Model.MedicApiAdapter;
import com.example.medic.Model.SharedPreferencesManager;
import com.example.medic.Model.User;
import com.example.medic.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrderActivity extends AppCompatActivity {

    private App app;
    private CartManager cartManager;
    private MedicApiAdapter apiAdapter;
    private SharedPreferencesManager sharedPreferencesManager;
    private AppCompatButton back;
    private EditText address;
    private EditText dateTime;
    private EditText phone;
    private EditText comment;
    private AppCompatButton order;
    private ImageView indicator;
    private BottomSheetDialog addressDialog;
    private BottomSheetDialog dateDialog;
    private List<User> usersList;

    private DatePickerDialog datePickerDialog;
    private boolean save = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        app = (App) getApplication();
        cartManager = app.getCartManager();
        apiAdapter = app.getMedicApiAdapter();
        sharedPreferencesManager = app.getSharedPreferencesManager();

        address = findViewById(R.id.address);
        dateTime = findViewById(R.id.date_time);
        phone = findViewById(R.id.phone_number);
        order = findViewById(R.id.proceed_order);
        back = findViewById(R.id.back);
        comment = findViewById(R.id.comment);

        initUsersList();

        initAddressDialog();
        initDateDialog();

        initTextWatcher();

        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                proceedOrder();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
    }

    private void proceedOrder() {

//        Call<User> call = apiAdapter.getApi().createOrder("Bearer "+ sharedPreferencesManager.getToken(), address.getText().toString(), phone.getText().toString(), dateTime.getText().toString(), comment.getText().toString(), "", usersList);
//        call.enqueue(new Callback<User>() {
//            @Override
//            public void onResponse(Call<User> call, Response<User> response) {
//
//            }
//
//            @Override
//            public void onFailure(Call<User> call, Throwable t) {
//
//            }
//        });


        setContentView(R.layout.payment_view);

        indicator = findViewById(R.id.indicator);
        indicator.animate().rotationBy(36000).setDuration(100000).setInterpolator(new LinearInterpolator()).start();
        TextView title = findViewById(R.id.title);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                title.setText("Производим оплату...");
            }
        }, 3000);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                toNextActivity();
            }
        }, 5000);

    }

    private void initAddressDialog() {
        addressDialog = new BottomSheetDialog(this);
        addressDialog.setContentView(R.layout.bottom_sheet_address);

        address.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    address.clearFocus();
                    addressDialog.show();
                }
            }
        });

        EditText sheet_address = addressDialog.findViewById(R.id.sheet_address);
        EditText l = addressDialog.findViewById(R.id.l);
        EditText w = addressDialog.findViewById(R.id.w);
        EditText h = addressDialog.findViewById(R.id.h);
        EditText apartment = addressDialog.findViewById(R.id.apartment);
        EditText entrance = addressDialog.findViewById(R.id.entrance);
        EditText floor = addressDialog.findViewById(R.id.floor);

        Switch sw = addressDialog.findViewById(R.id.save);

        sheet_address.setText(sharedPreferencesManager.getAddress().getAddress());
        l.setText(String.valueOf(sharedPreferencesManager.getAddress().getL()));
        w.setText(String.valueOf(sharedPreferencesManager.getAddress().getW()));
        h.setText(String.valueOf(sharedPreferencesManager.getAddress().getH()));
        apartment.setText(String.valueOf(sharedPreferencesManager.getAddress().getApartment()));
        entrance.setText(String.valueOf(sharedPreferencesManager.getAddress().getEntrance()));
        floor.setText(String.valueOf(sharedPreferencesManager.getAddress().getFloor()));
        AppCompatButton sheet_confirm = addressDialog.findViewById(R.id.confirm);


        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    save = true;
                } else {
                    save = false;
                }
            }
        });

        sheet_confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                address.setText(sheet_address.getText().toString() + ", кв. " + apartment.getText().toString());

                if (save) {
                    sharedPreferencesManager.saveAddress(address.getText().toString(),
                            Integer.parseInt(l.getText().toString()),
                            Integer.parseInt(w.getText().toString()),
                            Integer.parseInt(h.getText().toString()),
                            Integer.parseInt(apartment.getText().toString()),
                            Integer.parseInt(entrance.getText().toString()),
                            Integer.parseInt(floor.getText().toString()));
                }
                addressDialog.cancel();
            }
        });
    }

    private void initTextWatcher() {
        order.setEnabled(false);

        TextWatcher textWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                validateInput();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };

        address.addTextChangedListener(textWatcher);
        dateTime.addTextChangedListener(textWatcher);
        phone.addTextChangedListener(textWatcher);
    }

    private void validateInput() {
        if (address.getText().toString().length() > 0 &&
                dateTime.getText().toString().length() > 0 &&
                usersList.size() > 0 &&
                phone.getText().toString().length() == 11) {
            order.setEnabled(true);
            order.setBackgroundResource(R.drawable.button_active_blue);
        } else {
            order.setEnabled(false);
            order.setBackgroundResource(R.drawable.button_inactive_blue);
        }
    }

    private void initDateDialog() {
        dateDialog = new BottomSheetDialog(this);
        dateDialog.setContentView(R.layout.bottom_sheet_date);

        TextView date = dateDialog.findViewById(R.id.date_text);
        LinearLayout dateBg = dateDialog.findViewById(R.id.date_picker);
        AppCompatButton confirmDate = dateDialog.findViewById(R.id.confirm_date);

        datePickerDialog = new DatePickerDialog(this);
        datePickerDialog.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                date.setText(dayOfMonth + "." + month + "." + year);
            }
        });

        dateTime.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    dateTime.clearFocus();
                    dateDialog.show();
                }
            }
        });

        dateBg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePickerDialog.show();
            }
        });

        confirmDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dateTime.setText(date.getText().toString());
                dateDialog.cancel();
            }
        });

    }

    private void initUsersList() {
        usersList = new ArrayList<>();
        usersList.add(new User("Тицкий Эдуард", cartManager.getCartList()));
    }

    private void toNextActivity() {
        startActivity(new Intent(this, FinalActivity.class));
        this.finish();
    }

    private void back() {
        this.finish();
    }
}