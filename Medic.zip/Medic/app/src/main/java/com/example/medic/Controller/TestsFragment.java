package com.example.medic.Controller;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.medic.Model.App;
import com.example.medic.Model.CartManager;
import com.example.medic.Model.MedicApiAdapter;
import com.example.medic.Model.CatalogueResponse;
import com.example.medic.Model.SalesResponse;
import com.example.medic.R;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//  13.04.2023
//  Баюков Даниил
//  фрагмент с тестами

public class TestsFragment extends Fragment {

    private RecyclerView catalogueView;
    private RecyclerView salesView;

    private App app;
    private MedicApiAdapter medicApiAdapter;

    private List<SalesResponse> salesResponseList;
    private List<CatalogueResponse> catalogueResponseList;
    private SalesAdapter salesAdapter;
    private CatalogueAdapter catalogueAdapter;

    private BottomSheetDialog bottomSheetDialog;

    private SearchView searchView;

    private AppCompatButton filter1;
    private AppCompatButton filter2;
    private AppCompatButton filter3;
    private AppCompatButton filter4;

    private LinearLayout cartBackground;
    private LinearLayout cartButton;
    private TextView price;

    private CartManager cartManager;

    public TestsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        app = (App) requireActivity().getApplication();
        medicApiAdapter = app.getMedicApiAdapter();
        cartManager = app.getCartManager();

        return inflater.inflate(R.layout.fragment_tests, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        salesView = requireView().findViewById(R.id.sales_view);
        catalogueView = requireView().findViewById(R.id.catalogue_view);

        searchView = requireView().findViewById(R.id.searchView);
        bottomSheetDialog = new BottomSheetDialog(getContext());
        bottomSheetDialog.setContentView(R.layout.bottom_sheet_catalog);

        cartBackground = requireView().findViewById(R.id.to_cart);
        cartButton = requireView().findViewById(R.id.cart_button);
        price = requireView().findViewById(R.id.button_price);

        searchView.setOnQueryTextFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    searchView.clearFocus();
                    toSearchActivity();
                }
            }
        });

        requestSales();
        requestCatalogue();
        setupFilters();

        cartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toCart();
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        setupCartManager();
    }

    private void setupCartManager() {
        updatePrice();
        cartManager.setOnCartElementChangedListener(new CartManager.CartElementChangedListener() {
            @Override
            public void onCartElementChanged(CatalogueResponse cartElement) {
                updatePrice();
            }

            @Override
            public void onCartCleaned() {
                updatePrice();
            }
        });
    }

    private void updatePrice() {
        if (cartManager.getCartList().size() > 0) {
            cartBackground.setVisibility(View.VISIBLE);
        } else {
            cartBackground.setVisibility(View.INVISIBLE);
        }
        int total = 0;
        for (CatalogueResponse cartElement : cartManager.getCartList()) {
            total += Integer.parseInt(cartElement.getPrice()) * cartElement.getAmount();
        }
        if (total == 0) {
            cartBackground.setVisibility(View.INVISIBLE);
        }
        price.setText(String.valueOf(total) + " Р");
    }


    //Метод запрашивающий новости с сервера
    private void requestSales() {
        Call<List<SalesResponse>> call = medicApiAdapter.getApi().requestSales();
        call.enqueue(new Callback<List<SalesResponse>>() {
            @Override
            public void onResponse(Call<List<SalesResponse>> call, Response<List<SalesResponse>> response) {
                if (response.code() == 200) {
                    salesResponseList = response.body();
                    setupSalesAdapter(salesResponseList);
                } else {
                    Toast.makeText(getContext(), "Произошла ошибка", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<SalesResponse>> call, Throwable t) {

            }
        });
    }

    //Метод запрашивающий каталог с сервера
    private void requestCatalogue() {
        Call<List<CatalogueResponse>> call = medicApiAdapter.getApi().requestCatalogue();
        call.enqueue(new Callback<List<CatalogueResponse>>() {
            @Override
            public void onResponse(Call<List<CatalogueResponse>> call, Response<List<CatalogueResponse>> response) {
                if (response.code() == 200) {
                    catalogueResponseList = response.body();
                    setupCatalogueAdapter(catalogueResponseList);
                } else {
                    Toast.makeText(getContext(), "Произошла ошибка", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<List<CatalogueResponse>> call, Throwable t) {

            }
        });
    }

    //Метод для инициализации каталога

    private void setupCatalogueAdapter(List<CatalogueResponse> catalogueResponseList) {
        catalogueAdapter = new CatalogueAdapter(catalogueResponseList, getContext(), bottomSheetDialog, cartManager);
        catalogueView.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.VERTICAL, false));
        catalogueView.setAdapter(catalogueAdapter);
    }

    //Метод для инициализации новостей
    private void setupSalesAdapter(List<SalesResponse> salesResponseList) {
        salesAdapter = new SalesAdapter(salesResponseList, getContext());
        salesView.setLayoutManager(new LinearLayoutManager(getContext(), RecyclerView.HORIZONTAL, false));
        salesView.setAdapter(salesAdapter);
    }

    //Метод для инициализации кнопок фильтров

    private void setupFilters() {
        filter1 = requireView().findViewById(R.id.popular);
        filter2 = requireView().findViewById(R.id.covid);
        filter3 = requireView().findViewById(R.id.cancer);
        filter4 = requireView().findViewById(R.id.healthy);

        AppCompatButton[] filter = {
                filter1,
                filter2,
                filter3,
                filter4
        };

        View.OnClickListener filterClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AppCompatButton button = (AppCompatButton) v;
                String filterText = button.getText().toString();
                for (AppCompatButton btn : filter) {
                    btn.setBackgroundResource(R.drawable.button_inactive_gray);
                    btn.setTextColor(Color.GRAY);
                }
                button.setBackgroundResource(R.drawable.button_active_blue);
                button.setTextColor(Color.WHITE);
            }
        };

        for (AppCompatButton button : filter) {
            button.setOnClickListener(filterClickListener);
        }
    }

    //Метод для перехода в активити поиска
    private void toSearchActivity() {
        Intent intent = new Intent(getActivity(), SearchActivity.class);
        startActivity(intent);
    }

    private void toCart() {
        Intent intent = new Intent(getContext(), CartActivity.class);
        startActivity(intent);
    }
}