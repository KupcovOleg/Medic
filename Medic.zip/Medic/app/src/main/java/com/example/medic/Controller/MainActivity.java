package com.example.medic.Controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.example.medic.R;
import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {
    private TabLayout tabLayout;

    FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tabLayout = findViewById(R.id.tab_layout);

        fragmentManager = getSupportFragmentManager();
        setupTabs();
    }

    private void setupTabs() {
        tabLayout.addTab(tabLayout.newTab().setText("Анализы").setIcon(R.drawable.icon_tests));
        tabLayout.addTab(tabLayout.newTab().setText("Результаты").setIcon(R.drawable.icon_results));
        tabLayout.addTab(tabLayout.newTab().setText("Поддержка").setIcon(R.drawable.icon_support));
        tabLayout.addTab(tabLayout.newTab().setText("Профиль").setIcon(R.drawable.icon_user));

        setFrame(new TestsFragment());

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                Fragment fragment = null;
                switch (tab.getPosition()) {
                    case 0:
                        fragment = new TestsFragment();
                        break;
                    case 1:
                    case 2:
                        fragment = new BlankFragment();
                        break;
                    case 3:
                        fragment = new UserFragment();
                        break;
                }
                setFrame(fragment);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
    }

    private void setFrame(Fragment fragment) {
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame_layout, fragment);
        fragmentTransaction.commit();
    }


}