package com.example.medic.Controller;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.medic.Model.SalesResponse;
import com.example.medic.R;

import java.util.List;

public class SalesAdapter extends RecyclerView.Adapter<SalesAdapter.SalesResponseView> {

    private List<SalesResponse> salesResponseList;
    private Context context;
    public SalesAdapter(List<SalesResponse> salesResponseList, Context context) {
        this.salesResponseList = salesResponseList;
        this.context = context;
    }

    @NonNull
    @Override
    public SalesResponseView onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sales_element_view, parent, false);
        return new SalesResponseView(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SalesResponseView holder, int position) {

        holder.title.setText(salesResponseList.get(position).getName());
        holder.description.setText(salesResponseList.get(position).getDescription());
        holder.price.setText(salesResponseList.get(position).getPrice() + " P");
        Glide.with(context).load(Uri.parse(salesResponseList.get(position).getImage())).into(holder.image);
    }

    @Override
    public int getItemCount() {
        return salesResponseList.size();
    }

    public class SalesResponseView extends RecyclerView.ViewHolder {

        private TextView title;
        private TextView description;
        private TextView price;
        private ImageView image;
        private CardView card;

        public SalesResponseView(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.title);
            description = itemView.findViewById(R.id.description);
            price = itemView.findViewById(R.id.price);
            image = itemView.findViewById(R.id.image);
            card = itemView.findViewById(R.id.card);
        }
    }
}
