package com.example.medic.Model;

import android.app.Application;

//    Класс приложения, не использован
//    12.04.23
//    Баюков Даниил

public class App extends Application {

    private SharedPreferencesManager sharedPreferencesManager;
    private MedicApiAdapter medicApiAdapter;
    private CartManager cartManager;
    @Override
    public void onCreate() {
        super.onCreate();

        this.sharedPreferencesManager = new SharedPreferencesManager(getApplicationContext());
        this.medicApiAdapter = new MedicApiAdapter();
        this.cartManager = new CartManager();
    }

    public SharedPreferencesManager getSharedPreferencesManager() {
        return sharedPreferencesManager;
    }

    public MedicApiAdapter getMedicApiAdapter() {
        return medicApiAdapter;
    }
    public CartManager getCartManager() {
        return cartManager;
    }
}
