package com.example.medic.Controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.medic.Model.App;
import com.example.medic.Model.CartManager;
import com.example.medic.R;

public class FinalActivity extends AppCompatActivity {

    private AppCompatButton toMain;
    private App app;
    private CartManager cartManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);

        toMain = findViewById(R.id.to_main);
        app = (App) getApplication();
        cartManager = app.getCartManager();

        cartManager.clearCart();

        toMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toMain();
            }
        });
    }

    private void toMain() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        this.finish();
    }
}