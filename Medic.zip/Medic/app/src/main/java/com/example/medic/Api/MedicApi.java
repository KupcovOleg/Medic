package com.example.medic.Api;

import com.example.medic.Model.CatalogueResponse;
import com.example.medic.Model.EmailResponse;
import com.example.medic.Model.SalesResponse;
import com.example.medic.Model.TokenResponse;
import com.example.medic.Model.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;

public interface MedicApi {

    @POST("api/sendCode")
    Call<EmailResponse> requestCode(
            @Header("email") String email
    );

    @POST("api/signin")
    Call<TokenResponse> requestToken(
            @Header("email") String email,
            @Header("code") String code
    );

    @GET("api/news")
    Call<List<SalesResponse>> requestSales();

    @GET("api/catalog")
    Call<List<CatalogueResponse>> requestCatalogue();

    @POST("api/order")
    Call<User> createOrder(
            @Header("Authentication") String token,
            @Body String address,
            String date_time,
            String phone,
            String comment,
            String audio_comment,
            List<User> patients
    );
}
