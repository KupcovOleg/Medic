package com.example.medic.Model;

import java.util.ArrayList;
import java.util.List;

public class CartManager {

    private List<CatalogueResponse> cartList;
    private CartElementChangedListener listener;

    public CartManager() {
        this.cartList = new ArrayList<>();
        this.listener = null;
    }

    public List<CatalogueResponse> getCartList() {
        return cartList;
    }

    public void addElement(CatalogueResponse element) {
        if (cartList.contains(element)) {
            element.increaseAmount();
        } else {
            cartList.add(element);
            element.increaseAmount();
        }
        if (listener != null) {
            listener.onCartElementChanged(element);
        }
    }

    public void removeElement(CatalogueResponse element) {
        if (cartList.contains(element)) {
            if (element.getAmount() > 1) {
                element.decreaseAmount();
            } else {
                cartList.remove(element);
            }
        }
        if (listener != null) {
            listener.onCartElementChanged(element);
        }
    }

    public void clearCart() {
        for (CatalogueResponse element : cartList) {
            element.setAmount(0);
        }
        cartList.clear();
        if (listener != null) {
            listener.onCartCleaned();
        }
    }

    public void clearElement(CatalogueResponse element) {
        if (cartList.contains(element)) {
            element.setAmount(0);
            cartList.remove(element);
        }
        if (listener != null) {
            listener.onCartElementChanged(element);
        }
    }

    public void setOnCartElementChangedListener(CartElementChangedListener listener) {
        this.listener = listener;
    }

    public interface CartElementChangedListener {
        void onCartElementChanged(CatalogueResponse cartElement);
        void onCartCleaned();
    }
}
