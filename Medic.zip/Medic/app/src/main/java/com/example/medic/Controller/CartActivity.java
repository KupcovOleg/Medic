package com.example.medic.Controller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.medic.Model.App;
import com.example.medic.Model.CartManager;
import com.example.medic.Model.CatalogueResponse;
import com.example.medic.R;

import org.w3c.dom.Text;

public class CartActivity extends AppCompatActivity {

    private TextView total;
    private AppCompatButton createOrder;
    private AppCompatButton back;
    private ImageView clear;

    private CartAdapter cartAdapter;
    private App app;
    private CartManager cartManager;

    private RecyclerView cartView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        app = (App) getApplication();
        cartManager = app.getCartManager();

        total = findViewById(R.id.sum);
        clear = findViewById(R.id.clear);
        back = findViewById(R.id.back);
        createOrder = findViewById(R.id.to_order);

        cartView = findViewById(R.id.cart_view);

        setupCartView();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });

        changeTotal();

        cartManager.setOnCartElementChangedListener(new CartManager.CartElementChangedListener() {
            @Override
            public void onCartElementChanged(CatalogueResponse cartElement) {
                changeTotal();
                cartAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCartCleaned() {
                changeTotal();
                cartAdapter.notifyDataSetChanged();
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cartManager.clearCart();
                cartAdapter.notifyDataSetChanged();
            }
        });

        createOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toOrder();
            }
        });
    }

    private void back() {
        this.finish();
    }

    private void changeTotal() {
        int tot = 0;
        for (CatalogueResponse cartElement : cartManager.getCartList()) {
            tot += Integer.parseInt(cartElement.getPrice()) * cartElement.getAmount();
        }

        total.setText(String.valueOf(tot) + " Р");
    }

    private void setupCartView() {
        cartAdapter = new CartAdapter(cartManager);
        cartView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false));
        cartView.setAdapter(cartAdapter);
    }

    private void toOrder() {
        Intent intent = new Intent(this, OrderActivity.class);
        startActivity(intent);
    }
}