package com.example.medic.Model;

import java.util.List;

public class User {

    private String name;
    private List<CatalogueResponse> items;

    public User(String name, List<CatalogueResponse> items) {
        this.name = name;
        this.items = items;
    }

    public String getName() {
        return name;
    }

    public List<CatalogueResponse> getItems() {
        return items;
    }
}
