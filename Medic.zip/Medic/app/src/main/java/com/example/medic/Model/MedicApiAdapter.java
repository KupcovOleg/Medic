package com.example.medic.Model;

import androidx.annotation.NonNull;

import com.example.medic.Api.MedicApi;

import java.io.IOException;

import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava.RxJavaCallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

    //

public class MedicApiAdapter {

    private MedicApi medicApi;


    public MedicApiAdapter() {
        Retrofit retrofit = createRetrofit();
        this.medicApi = retrofit.create(MedicApi.class);
    }


    private Retrofit createRetrofit() {
        return new Retrofit.Builder()
                .baseUrl("https://medic.madskill.ru/")
                .addConverterFactory(GsonConverterFactory.create())
                .client(createOkHTTPClient())
                .addCallAdapterFactory(RxJavaCallAdapterFactory.create())
                .build();
    }

    private OkHttpClient createOkHTTPClient() {
        OkHttpClient.Builder httpClient = new OkHttpClient.Builder();
        httpClient.addInterceptor(new Interceptor() {
            @NonNull
            @Override
            public Response intercept(@NonNull Chain chain) throws IOException {
                final Request orig = chain.request();
                final HttpUrl origHttpUrl = orig.url();
                final HttpUrl url = origHttpUrl.newBuilder().build();
                final Request.Builder requestBuilder = orig.newBuilder()
                        .url(url);
                final Request request = requestBuilder.build();
                return chain.proceed(request);
            }
        });

        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);
        httpClient.addInterceptor(logging);
        return httpClient.build();
    }

    public MedicApi getApi() {
        return medicApi;
    }
}
